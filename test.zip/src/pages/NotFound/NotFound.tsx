import React from "react";

const NotFound = () => {
  return <p>"404 no page like that brother"</p>;
};

export default NotFound;
