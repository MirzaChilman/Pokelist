export const TEXT = {
  COLOR: {
    main: "#ececec",
  },
};

export const BACKGROUND = {
  COLOR: {
    main: "#30475e",
    secondary: "#f2a365",
  },
};

export const BOX = {
  COLOR: {
    border: "#f2a365",
  },
};
