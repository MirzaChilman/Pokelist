/**
 * File to declare all module that does not support in both webpack loader
 * or do not have typing in it
 */
declare module "*.svg";
declare module "*.png";
declare module "*.jpg";
